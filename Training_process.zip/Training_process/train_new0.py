import numpy as np
import torch

print(torch.__version__)
print(torch.version.cuda)
print(torch.cuda.is_available)


import torch.nn.functional as F
import pandas as pd
#import torchvision
import matplotlib.pyplot as plt
import torch.utils.data as Data
#import xlrd
#import math
import sys
import os
import scipy.io as scio
import wandb
from tqdm import tqdm
import time
from datetime import datetime, timedelta  
import argparse
from sklearn.model_selection import train_test_split

today = (datetime.now()).strftime('%m%d')  
nowloc = os.path.split(os.path.realpath(__file__))[0]

# Load data from CSV file
io1 = '../Dataset/ML_Data_P.csv'
datapath = os.path.join(nowloc, io1)

# Read CSV file using pandas, skipping the first row (title)
data = pd.read_csv(datapath, skiprows=1)

# Set up argument parser
parser = argparse.ArgumentParser(description="Select specific columns for input features.")
parser.add_argument("--columns", type=int, nargs='+', required=True, help="List of column indices to select (e.g., --columns 3 4 5 6 7)")
args = parser.parse_args()

# Use the specified column indices from argparse
specific_columns = args.columns

model_save_path_best = os.path.join(nowloc,'Best_model_p1_new_{}.pth'.format(specific_columns))

# Normalize the specified columns individually
selected_columns = []
for col in specific_columns:
    column_data = data.iloc[:, col].values
    normalized_column = (column_data - np.min(column_data)) / (np.max(column_data) - np.min(column_data))
    selected_columns.append(normalized_column)

# Stack normalized selected columns and convert to tensor
init_input = torch.Tensor(np.column_stack(selected_columns))
print(f"Selected columns: {specific_columns}")

# Extract input features and target labels
# First 3 columns are ground truth force and position (target), last 9 columns are signals (input features)
# Normalize the first 3 columns (target) individually and stack them
normalized_target_columns = []
for col in range(3):
    column_data = data.iloc[:, col].values
    normalized_column = (column_data - np.min(column_data)) / (np.max(column_data) - np.min(column_data))
    normalized_target_columns.append(normalized_column)

target = torch.Tensor(np.column_stack(normalized_target_columns))  # First 3 columns normalized and stacked
# Normalize each column individually
normalized_columns = []
for col in range(3, data.shape[1]):
    column_data = data.iloc[:, col].values
    normalized_column = (column_data - np.min(column_data)) / (np.max(column_data) - np.min(column_data))
    normalized_columns.append(normalized_column)

# Stack normalized columns and convert to tensor
# init_input = torch.Tensor(np.column_stack(normalized_columns))
# print(init_input)

# Ensure the number of samples in init_input matches target
if init_input.shape[0] != target.shape[0]:
    raise ValueError(f"Size mismatch: init_input has {init_input.shape} samples, but target has {target.shape} samples.")

print(init_input.shape)
print(target.shape)
input_feature = init_input.shape[1]

# Define the MLP model
class MNN(torch.nn.Module):
    def __init__(self):
        super(MNN,self).__init__()    
        self.all = torch.nn.Sequential(
            torch.nn.Linear(input_feature,64),
            torch.nn.ReLU(),
            torch.nn.Linear(64,256),
            torch.nn.ReLU(),
            torch.nn.Linear(256,1024),
            torch.nn.ReLU(),    
            torch.nn.Linear(1024,256),
            torch.nn.ReLU(),                     
            torch.nn.Linear(256,64),
            torch.nn.ReLU(),
            torch.nn.Linear(64,3),
            torch.nn.Sigmoid()
        )
    def forward(self,x):
        output2 = self.all(x)
        return output2

class CNN(torch.nn.Module):
    def __init__(self):
        super(CNN, self).__init__()
        self.conv_layers = torch.nn.Sequential(
            torch.nn.Conv1d(in_channels=1, out_channels=16, kernel_size=3, stride=1, padding=1),
            torch.nn.ReLU(),
            torch.nn.MaxPool1d(kernel_size=2, stride=2),
            torch.nn.Conv1d(in_channels=16, out_channels=32, kernel_size=3, stride=1, padding=1),
            torch.nn.ReLU(),
            torch.nn.MaxPool1d(kernel_size=2, stride=2)
        )
        self.fc_layers = torch.nn.Sequential(
            torch.nn.Linear(32 * (input_feature // 4), 256),
            torch.nn.ReLU(),
            torch.nn.Linear(256, 64),
            torch.nn.ReLU(),
            torch.nn.Linear(64, 3),
            torch.nn.Sigmoid()
        )

    def forward(self, x):
        x = x.unsqueeze(1)  # Add channel dimension for Conv1d
        x = self.conv_layers(x)
        x = x.view(x.size(0), -1)  # Flatten for fully connected layers
        output = self.fc_layers(x)
        return output
    
class ResMLP(torch.nn.Module):
    def __init__(self):
        super(ResMLP, self).__init__()
        self.fc1 = torch.nn.Linear(input_feature, 64)
        self.fc2 = torch.nn.Linear(64, 256)
        self.fc3 = torch.nn.Linear(256, 1024)
        self.fc4 = torch.nn.Linear(1024, 256)
        self.fc5 = torch.nn.Linear(256, 64)
        self.fc6 = torch.nn.Linear(64, 3)
        self.relu = torch.nn.ReLU()
        self.sigmoid = torch.nn.Sigmoid()

    def forward(self, x):
        residual = self.fc6(self.relu(self.fc5(self.relu(self.fc4(self.relu(self.fc3(self.relu(self.fc2(self.relu(self.fc1(x)))))))))))  # Transform residual to match dimensions
        x = self.relu(self.fc1(x))
        x = self.relu(self.fc2(x))
        x = self.relu(self.fc3(x))
        x = self.relu(self.fc4(x))
        x = self.relu(self.fc5(x))
        x = self.fc6(x)
        x = self.sigmoid(x)
        return x + residual  # Adding residual connection


# Initialize wandb for logging
wandb.init(project="train_new_sandwich", name="ResMLP_model_{}".format(specific_columns))

# Hyperparameters
input_dim = init_input.shape[1]
output_dim = target.shape[1]
hidden_dim = 64
learning_rate = 0.001
epochs = 10000
batch_size = 256

# Split data into train and validation sets
train_input, val_input, train_target, val_target = train_test_split(
    init_input, target, test_size=0.2, random_state=42
)

train_dataset = Data.TensorDataset(train_input, train_target)
val_dataset = Data.TensorDataset(val_input, val_target)

train_loader = Data.DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
val_loader = Data.DataLoader(val_dataset, batch_size=batch_size, shuffle=False)

# Initialize model, loss function, and optimizer
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
model = ResMLP().to(device)  # or CNN().to(device) if you want to use the CNN model
criterion = torch.nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

def dice_coefficient(pred, target, epsilon=1e-6):
    pred = pred > 0.5  # Binarize predictions
    target = target > 0.5  # Binarize targets
    intersection = (pred & target).float().sum()
    union = pred.float().sum() + target.float().sum()
    dice = (2. * intersection + epsilon) / (union + epsilon)
    return dice

# Training loop with validation
best_val_loss = float('inf')
for epoch in range(epochs):
    model.train()
    epoch_loss = 0
    dice_scores = []
    for batch_input, batch_target in train_loader:
        batch_input, batch_target = batch_input.to(device), batch_target.to(device)
        optimizer.zero_grad()
        predictions = model(batch_input)
        loss = criterion(predictions, batch_target)
        loss.backward()
        optimizer.step()
        epoch_loss += loss.item()
        dice_score = dice_coefficient(predictions, batch_target)
        dice_scores.append(dice_score.item())

    avg_loss = epoch_loss / len(train_loader)
    avg_dice = sum(dice_scores) / len(dice_scores)

    # Validation
    model.eval()
    val_loss = 0
    val_dice_scores = []
    with torch.no_grad():
        for val_input_batch, val_target_batch in val_loader:
            val_input_batch, val_target_batch = val_input_batch.to(device), val_target_batch.to(device)
            val_pred = model(val_input_batch)
            loss = criterion(val_pred, val_target_batch)
            val_loss += loss.item()
            val_dice = dice_coefficient(val_pred, val_target_batch)
            val_dice_scores.append(val_dice.item())
    avg_val_loss = val_loss / len(val_loader)
    avg_val_dice = sum(val_dice_scores) / len(val_dice_scores)

    # Log metrics to wandb
    wandb.log({
        "epoch": epoch + 1,
        "train_loss": avg_loss,
        "train_dice": avg_dice,
        "val_loss": avg_val_loss,
        "val_dice": avg_val_dice
    })

    print(f"Epoch {epoch + 1}/{epochs}, Train Loss: {avg_loss:.4f}, Train Dice: {avg_dice:.4f}, Val Loss: {avg_val_loss:.4f}, Val Dice: {avg_val_dice:.4f}")

    # Save best model
    if avg_val_loss < best_val_loss:
        best_val_loss = avg_val_loss
        torch.save(model.state_dict(), model_save_path_best)

wandb.finish()

# # Create DataLoader
# dataset = Data.TensorDataset(init_input, target)
# data_loader = Data.DataLoader(dataset, batch_size=batch_size, shuffle=True)

# # Initialize model, loss function, and optimizer
# device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
# model = ResMLP().to(device)  # or CNN().to(device) if you want to use the CNN model
# criterion = torch.nn.MSELoss()
# optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

# def dice_coefficient(pred, target, epsilon=1e-6):
#     pred = pred > 0.5  # Binarize predictions
#     target = target > 0.5  # Binarize targets
#     intersection = (pred & target).float().sum()
#     union = pred.float().sum() + target.float().sum()
#     dice = (2. * intersection + epsilon) / (union + epsilon)
#     return dice

# # Training loop
# for epoch in range(epochs):
#     epoch_loss = 0
#     dice_scores = []
#     for batch_input, batch_target in data_loader:
#         optimizer.zero_grad()
#         predictions = model(batch_input)
#         loss = criterion(predictions, batch_target)
#         loss.backward()
#         optimizer.step()
#         epoch_loss += loss.item()

#         # Calculate Dice score
#         intersection = torch.sum(predictions * batch_target, dim=1)
#         # dice_score = (2 * intersection) / (torch.sum(predictions, dim=1) + torch.sum(batch_target, dim=1) + 1e-6)
#         dice_score = dice_coefficient(predictions, batch_target)
#         dice_scores.append(dice_score.mean().item())

#     avg_loss = epoch_loss / len(data_loader)
#     avg_dice = sum(dice_scores) / len(dice_scores)

#     # Log metrics to wandb
#     wandb.log({"epoch": epoch + 1, "loss": avg_loss, "dice_score": avg_dice})

#     print(f"Epoch {epoch + 1}/{epochs}, Loss: {avg_loss:.4f}, Dice Score: {avg_dice:.4f}")

# # Save the best model
# torch.save(model.state_dict(), model_save_path_best)
# wandb.finish()