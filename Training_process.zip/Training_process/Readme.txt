"train_new" is the code for single point touch (8 inputs from sensor signals, 3 outputs: X coordinate, Y coordinate and force F).

"train_new_2_Point" is the code for two point touch (8 inputs from sensor signals, 6 outputs: X1, X2, Y1, Y2 and force F1, F2).

All the training data is in the <Dataset> folder.