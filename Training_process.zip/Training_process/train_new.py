#!/usr/bin/env python3
import numpy as np
import torch
import pandas as pd
import matplotlib.pyplot as plt
import torch.utils.data as Data
import os
import wandb
from tqdm import tqdm
from datetime import datetime, timedelta
import argparse
from sklearn.model_selection import train_test_split

# Define the MLP model
class MNN(torch.nn.Module):
    def __init__(self, input_feature, l1_size, l2_size, l3_size, dropout_p, output_feature=3):
        super(MNN, self).__init__()
        self.all = torch.nn.Sequential(
            torch.nn.Linear(input_feature, l1_size),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_p),
            torch.nn.Linear(l1_size, l2_size),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_p),
            torch.nn.Linear(l2_size, l3_size),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_p),
            torch.nn.Linear(l3_size, l2_size),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_p),
            torch.nn.Linear(l2_size, l1_size),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_p),
            torch.nn.Linear(l1_size, output_feature),
            torch.nn.Sigmoid()
        )

    def forward(self, x):
        output2 = self.all(x)
        return output2

# # Define the CNN model
# class CNN(torch.nn.Module):
#     def __init__(self, input_feature, l1_size=64, l2_size=128, l3_size=1024, output_feature=3):
#         super(CNN, self).__init__()
#         self.conv_layers = torch.nn.Sequential(
#             torch.nn.Conv1d(in_channels=1, out_channels=16, kernel_size=3, stride=1, padding=1),
#             torch.nn.ReLU(),
#             torch.nn.MaxPool1d(kernel_size=2, stride=2),
#             torch.nn.Conv1d(in_channels=16, out_channels=32, kernel_size=3, stride=1, padding=1),
#             torch.nn.ReLU(),
#             torch.nn.MaxPool1d(kernel_size=2, stride=2)
#         )
#         self.fc_layers = torch.nn.Sequential(
#             torch.nn.Linear(32 * (input_feature // 4), 256),
#             torch.nn.ReLU(),
#             torch.nn.Linear(256, 64),
#             torch.nn.ReLU(),
#             torch.nn.Linear(64, 3),
#             torch.nn.Sigmoid()
#         )

#     def forward(self, x):
#         x = x.unsqueeze(1)  # Add channel dimension for Conv1d
#         x = self.conv_layers(x)
#         x = x.view(x.size(0), -1)  # Flatten for fully connected layers
#         output = self.fc_layers(x)
#         return output

# # Define the ResMLP model
# class ResMLP(torch.nn.Module):
#     def __init__(self, input_feature, l1_size=64, l2_size=128, l3_size=1024, output_feature=3):

#         super(ResMLP, self).__init__()
#         self.fc1 = torch.nn.Linear(input_feature, l1_size)
#         self.fc2 = torch.nn.Linear(l1_size, l2_size)
#         self.fc3 = torch.nn.Linear(l2_size, l3_size)
#         self.fc4 = torch.nn.Linear(l3_size, l2_size)
#         self.fc5 = torch.nn.Linear(l2_size, l1_size)
#         self.fc6 = torch.nn.Linear(l1_size, output_feature)
#         self.relu = torch.nn.ReLU()
#         self.sigmoid = torch.nn.Sigmoid()

#     def forward(self, x):
#         residual = self.fc6(self.relu(self.fc5(self.relu(self.fc4(self.relu(
#             self.fc3(self.relu(self.fc2(self.relu(self.fc1(x)))))))))))  # Transform residual to match dimensions
#         x = self.relu(self.fc1(x))
#         x = self.relu(self.fc2(x))
#         x = self.relu(self.fc3(x))
#         x = self.relu(self.fc4(x))
#         x = self.relu(self.fc5(x))
#         x = self.fc6(x)
#         x = self.sigmoid(x)
#         return x + residual  # Adding residual connection
#         # return x

def dice_coefficient(pred, target, epsilon=1e-6):
    pred = pred > 0.5  # Binarize predictions
    target = target > 0.5  # Binarize targets
    intersection = (pred & target).float().sum()
    union = pred.float().sum() + target.float().sum()
    dice = (2. * intersection + epsilon) / (union + epsilon)
    return dice

def train(model, data_loader, optimizer, criterion):
    epoch_loss = 0
    dice_scores = []
    for batch_input, batch_target in data_loader:
    # for batch_target, batch_input in data_loader:
        # print(batch_input)
        optimizer.zero_grad()
        predictions = model(batch_input)
        loss = criterion(predictions, batch_target)
        loss.backward()
        optimizer.step()
        # print("debug",predictions,batch_target)
        dice_score = dice_coefficient(predictions, batch_target)

        epoch_loss += loss.item()
        dice_scores.append(dice_score.mean().item())

    return epoch_loss, dice_scores

def validate(model, data_loader, criterion):
    epoch_loss = 0
    dice_scores = []
    model.eval()
    with torch.no_grad():
        for batch_input, batch_target in data_loader:
        # for batch_target, batch_input in data_loader:
            # optimizer.zero_grad()
            predictions = model(batch_input)
            loss = criterion(predictions, batch_target)
            # loss.backward()
            # optimizer.step()
            # Calculate Dice score
            # intersection = torch.sum(predictions * batch_target, dim=1)
            # dice_score = (2 * intersection) / (torch.sum(predictions, dim=1) + torch.sum(batch_target, dim=1) + 1e-6)
            dice_score = dice_coefficient(predictions, batch_target)

            epoch_loss += loss.item()
            dice_scores.append(dice_score.mean().item())

    return epoch_loss, dice_scores

def train_MLP():
    # Hyperparameters
    # input_dim = init_input.shape[1]
    # output_dim = target.shape[1]
    learning_rate = 0.00005
    epochs = 500
    batch_size = 4
    l1 = 16
    l2 = 64
    l3 = 256
    DP = 0       # dropout probability
    WD = 0      # weight decay

    with wandb.init(project="train_new_sandwich", name=f"P{learning_rate}, {batch_size}, {l1}-{l2}-{l3}, WD={WD}, DP={DP}") as run:
        # Load data and create dataloaders
        input_feature, train_set, valid_set, col_min, col_max, testset = load_data(nowloc, specific_columns)
        data_loader = Data.DataLoader(train_set, batch_size=batch_size, shuffle=True)
        valid_loader = Data.DataLoader(valid_set, batch_size=batch_size, shuffle=False)
        test_loader = Data.DataLoader(testset, batch_size=batch_size, shuffle=False)

        # Initialize model, loss function, and optimizer
        model = MNN(input_feature, l1_size=l1, l2_size=l2, l3_size=l3, dropout_p=DP).to(device)  # or CNN().to(device) if you want to use the CNN model
        
        criterion = torch.nn.MSELoss()

        #################### weight decay #############################
        # optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
        optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate, weight_decay=WD)
        ###################### weight decay #############################
        
        # optional: track gradients
        wandb.watch(model)

        # Training loop
        for epoch in range(epochs):
            # Training
            epoch_loss, dice_scores = train(model, data_loader, optimizer, criterion)
            
            # Metrics
            avg_loss = epoch_loss / len(data_loader)
            avg_dice = sum(dice_scores) / len(dice_scores)

            # Validation
            epoch_loss, dice_scores = validate(model, valid_loader, criterion)
            valid_loss = epoch_loss / len(valid_loader)
            valid_dice_scores = sum(dice_scores) / len(dice_scores)
        
            epoch_loss, dice_scores = validate(model, test_loader, criterion)
            test_loss = epoch_loss / len(test_loader)
            test_dice_scores = sum(dice_scores) / len(dice_scores)

            # Log metrics to wandb
            wandb.log({"epoch": epoch + 1, "loss": avg_loss, "dice_score": avg_dice, "valid_loss": valid_loss,
                    "valid_dice_score": valid_dice_scores})

            print( f"Epoch {epoch + 1}/{epochs}, Loss: {avg_loss:.4f},Dice Score: {avg_dice:.4f}, "
                   f"Vloss: {valid_loss:.4f}, VDice Score: {valid_dice_scores:.4f}, "
                   f"Tloss: {test_loss:.4f}, TDice Score: {test_dice_scores:.4f}, "
                #    f"Best Vloss: {best_valid_loss:.4f}, Epoch passed: {epochs_no_improve}"
                )
            
            # Early stopping if training loss is less than 0.03
            if avg_loss < 0.02:
                print(f"Early stopping at epoch {epoch+1}: training loss {avg_loss:.4f} < 0.03")
                break                    

        checkpoint_data = {
            "epoch": epoch,
            "net_state_dict": model.state_dict(),
            "optimizer_state_dict": optimizer.state_dict(),
        }

    return model, data_loader, valid_loader


def normalized_data(data, specific_columns, col_min, col_max):

    selected_columns = []
    
    for col in specific_columns:
        column_data = data.iloc[:, col].values
        normalized_column = (column_data - np.min(column_data)) / (np.max(column_data) - np.min(column_data))
        selected_columns.append(normalized_column)

    normalized_data = (data - col_min) / (col_max - col_min)

    return normalized_data

#  return input_feature, train_set, valid_set, col_min, col_max, testset
def load_data(nowloc, specific_columns):
    # Load data from CSV file
    io1 = '../Dataset/ML_Data_P_New.csv'
    datapath = os.path.join(nowloc, io1)

    # Read CSV file using pandas, skipping the first row (title)
    data_raw = pd.read_csv(datapath, skiprows=1, header=None)

    # Compute min and max on the whole dataset, then normalize the entire dataset first
    col_max = data_raw.max()
    col_min = data_raw.min()
    print("debug", (col_max - col_min))

    # Normalize entire dataframe
    data_norm = (data_raw - col_min) / (col_max - col_min)

    # Now split the normalized data into train / valid / test
    test_set_size  = int(len(data_norm) * 0.15)
    valid_set_size = int(len(data_norm) * 0.15)

    train_temp, test_data = train_test_split(data_norm, test_size=test_set_size, random_state=114)
    train_data, valid_data = train_test_split(train_temp, test_size=valid_set_size, random_state=114)

    # Separate dataset into input features and targets (already normalized)
    train_X = train_data[specific_columns].values
    train_y = train_data[[0, 1, 2]].values

    test_X = test_data[specific_columns].values
    test_y = test_data[[0, 1, 2]].values

    valid_X = valid_data[specific_columns].values
    valid_y = valid_data[[0, 1, 2]].values

    # Convert to torch tensors and move to device
    init_input = torch.Tensor(train_X).to(device)
    target = torch.Tensor(train_y).to(device)

    test_input = torch.Tensor(test_X).to(device)
    test_target = torch.Tensor(test_y).to(device)

    valid_input = torch.Tensor(valid_X).to(device)
    valid_target = torch.Tensor(valid_y).to(device)

    print(f"Selected columns: {specific_columns}")

    # Ensure the number of samples in init_input matches target
    if init_input.shape[0] != target.shape[0]:
        raise ValueError(
            f"Size mismatch: init_input has {init_input.shape} samples, but target has {target.shape} samples.")

    print(init_input.shape)
    print(target.shape)
    input_feature = init_input.shape[1]

    # Create Dataset
    # dataset = Data.TensorDataset(init_input, target)
    train_set = Data.TensorDataset(init_input, target)
    # testset = dataset
    testset = Data.TensorDataset(test_input, test_target)
    valid_set = Data.TensorDataset(valid_input, valid_target)

    return input_feature, train_set, valid_set, col_min, col_max, testset

specific_columns = [3, 4, 5, 6, 7, 8, 9, 10, 11] # 8 inputs for C, and 9 for P

print(torch.__version__)
print(torch.version.cuda)
print(torch.cuda.is_available)

# Define the device (e.g., CUDA if available, otherwise CPU)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Setup time for filename and directory
today = (datetime.now()).strftime('%m%d')
# nowloc = globals()['_dh'][0]
# nowloc = '/home/meyikkinc/Qian_CNN/final_code/Training_process'
nowloc = os.path.split(os.path.realpath(__file__))[0]

model_save_path_best = os.path.join(nowloc,'Best_model_P_MLP_{}.pth'.format(specific_columns))

model, data_loader, valid_loader = train_MLP()

# # # Save the best model
# if config["save_model"]:
# torch.save(model.state_dict(), model_save_path_best)
torch.save(model.state_dict(), model_save_path_best)
wandb.finish()


# //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
# //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
# Load testset for evaluation
_, _, _, col_min, col_max, testset = load_data(nowloc, specific_columns)

# test the model and plot error distribution
import matplotlib.pyplot as plt

# Get test inputs and targets
test_inputs = testset.tensors[0]
test_targets = testset.tensors[1]

# Run inference
model.eval()
with torch.no_grad():
    preds = model(test_inputs).cpu().numpy()
    targets = test_targets.cpu().numpy()

# Denormalize predictions and targets
col_min = np.array(col_min).flatten()
col_max = np.array(col_max).flatten()
target_min = np.array([0, 0, 0.2])
target_max = np.array([102, 66, 1])

preds_denorm = preds * (target_max - target_min) + target_min
targets_denorm = targets * (target_max - target_min) + target_min

# Calculate errors for each output
errors = np.abs(preds_denorm - targets_denorm)  # shape: [num_samples, 3]

# Define error bins
bins = [0, 1, 2, 5, 10, np.inf]
bin_labels = ['0-1', '1-2', '2-5', '5-10', '>10']

# Plot bar charts for each output
output_names = ['X', 'Y', 'Force']
for i in range(3):
    counts, _ = np.histogram(errors[:, i], bins=bins)
    plt.figure()
    plt.bar(bin_labels, counts)
    plt.title(f'Error Distribution for {output_names[i]}')
    plt.xlabel('Absolute Error Range')
    plt.ylabel('Number of Samples')
    plt.tight_layout()
    plt.show()


# Export test errors to CSV
import pandas as pd

# Calculate errors for each output
errors = preds_denorm - targets_denorm  # shape: [num_samples, 3]
abs_errors = np.abs(errors)

# Export errors to CSV
df_errors = pd.DataFrame({
    'X_error': abs_errors[:, 0],
    'Y_error': abs_errors[:, 1],
    'F_error': abs_errors[:, 2]
})
df_errors.to_csv(os.path.join(nowloc, 'test_errors.csv'), index=False)
print("Test errors exported to test_errors.csv")