import torch
import numpy as np
import serial
import time
import tkinter as tk
from tkinter import Canvas

# define input feature size
input_feature = 9  # now expecting 9 values per read 

# load model paths
model1_path = r'd:/OneDrive/HKUST/(Doing)_Bio_inspired_Origami_Fish_Scale/ML_Code/Trained_model/P_MLP.pth'
model2_path = r'd:/OneDrive/HKUST/(Doing)_Bio_inspired_Origami_Fish_Scale/ML_Code/Trained_model/P2P_MLP.pth'  # update to your model2 file

# define the model architecture
class MNN(torch.nn.Module):
    def __init__(self, input_feature=9, l1_size=32, l2_size=128, l3_size=512, dropout_p=0, output_feature=3):
        super(MNN, self).__init__()
        self.all = torch.nn.Sequential(
            torch.nn.Linear(input_feature, l1_size),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_p),
            torch.nn.Linear(l1_size, l2_size),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_p),
            torch.nn.Linear(l2_size, l3_size),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_p),
            torch.nn.Linear(l3_size, l2_size),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_p),
            torch.nn.Linear(l2_size, l1_size),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_p),
            torch.nn.Linear(l1_size, output_feature),
            torch.nn.Sigmoid()
        )
    def forward(self, x):
        output2 = self.all(x)
        return output2

# instantiate model1 (3 outputs) - ensure input_feature matches checkpoint (9)
MN = MNN(input_feature=9, output_feature=3)
statedict = torch.load(model1_path, map_location='cuda:0')
MN.load_state_dict(statedict)
MN.eval()

# instantiate model2 (6 outputs for two forces) - ensure input_feature matches checkpoint (9)
MN2 = MNN(input_feature=9, output_feature=6)
statedict2 = torch.load(model2_path, map_location='cuda:0')
MN2.load_state_dict(statedict2)
MN2.eval()

# Serial port settings
SERIAL_PORT = 'COM5'
BAUD_RATE = 9600
TIMEOUT = 1

ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=TIMEOUT)
print(f"Listening to {SERIAL_PORT}...")

initial_value = None
# Replace these with your actual training min/max arrays
col_min = np.array([-36, -34, -32, -30, -37, -33, -46, -38, -36])  # shape: (9,)
col_max = np.array([457, 501, 512, 358, 374, 380, 367, 381, 420])  # shape: (9,)

col_min2 = np.array([-38, -53, -35, -17, -46, -31, -53, -18, -27])  # shape: (9,)
col_max2 = np.array([336, 393, 209, 397, 435, 310, 418, 459, 313])  # shape: (9,)

target_min = np.array([0, 0, 0.2])
target_max = np.array([87, 54, 1])

target_min2 = np.array([0, 0, 0.2, 0, 0, 0.2])
target_max2 = np.array([81, 54, 1, 81, 54, 1])

# GUI setup
root = tk.Tk()
root.title("Tactile Sensor Visualization")
canvas_width = 800
canvas_height = 600
canvas = Canvas(root, width=canvas_width, height=canvas_height, bg='white')
canvas.pack()

# Plot margins (leave room for axis labels and colorbar)
left_margin = 50
right_margin = 80
top_margin = 20
bottom_margin = 50

plot_x0 = left_margin
plot_y0 = top_margin
plot_x1 = canvas_width - right_margin
plot_y1 = canvas_height - bottom_margin
plot_width = plot_x1 - plot_x0
plot_height = plot_y1 - plot_y0

# Draw plot border and axis lines (tag as static so they are not removed)
canvas.create_rectangle(plot_x0, plot_y0, plot_x1, plot_y1, outline='black', tags=('static',))

# draw axis lines just outside the plot rectangle so ticks/labels sit outside
axis_offset = 1
canvas.create_line(plot_x0, plot_y1 + axis_offset, plot_x1, plot_y1 + axis_offset, width=2, tags=('static',))  # x axis just below plot
canvas.create_line(plot_x0 - axis_offset, plot_y0, plot_x0 - axis_offset, plot_y1, width=2, tags=('static',))  # y axis just left of plot

# Axis labels and ticks based on known target ranges
x_min, y_min = float(target_min[0]), float(target_min[1])
x_max, y_max = float(target_max[0]), float(target_max[1])

# X ticks (draw ticks outside the plot, below the axis)
num_xticks = 5
for i in range(num_xticks + 1):
    t = i / num_xticks
    x = int(plot_x0 + t * plot_width)
    y_tick = plot_y1 + axis_offset
    canvas.create_line(x, y_tick, x, y_tick + 6, tags=('static',))
    val = x_min + t * (x_max - x_min)
    canvas.create_text(x, y_tick + 18, text=f"{val:.0f}", tags=('static',))

# Y ticks (draw ticks outside the plot, to the left of the axis)
num_yticks = 5
for i in range(num_yticks + 1):
    t = i / num_yticks
    y = int(plot_y1 - t * plot_height)
    x_tick = plot_x0 - axis_offset
    canvas.create_line(x_tick - 6, y, x_tick, y, tags=('static',))
    val = y_min + t * (y_max - y_min)
    canvas.create_text(x_tick - 22, y, text=f"{val:.0f}", tags=('static',))

# Axis titles (move them outward slightly)
canvas.create_text(plot_x0 + plot_width / 2, canvas_height - 6, text="X position", font=("Arial", 13, "bold"), tags=('static',))
canvas.create_text(10, plot_y0 + plot_height / 2, text="Y position", angle=90, font=("Arial", 13, "bold"), tags=('static',))

# Reserve space for colorbar on the right and add label (colorbar itself will be drawn later)
# compute colorbar geometry so it fits inside the right margin and inside the plot vertical bounds
cb_width = 20
cb_height = max(40, plot_height - 20)            # keep a small vertical padding so it doesn't overflow
cb_x = plot_x1 + max(0, (right_margin - cb_width) // 2)  # center the colorbar inside the right margin
cb_y = plot_y0 + 10                              # small top padding

# place the "Force" label and leave numeric labels to draw_colorbar
canvas.create_text(cb_x + cb_width - 8, cb_y - 8, text="Force", font=("Arial", 13, "bold"), tags=('static',))
# add min/max labels placeholders (will be overwritten/duplicated by draw_colorbar call)
# canvas.create_text(cb_x + cb_width + 8, cb_y + cb_height + 6, text=f"{target_min[2]:.2f}", tags=('static',))
# canvas.create_text(cb_x + cb_width + 8, cb_y - 18, text=f"{target_max[2]:.2f}", tags=('static',))

# Prevent the main loop from completely erasing the static elements:
# replace canvas.delete so that "all" removes only non-static items
_orig_delete = canvas.delete
def _delete_wrapper(*args):
    if len(args) == 1 and args[0] == "all":
        # delete everything that does NOT have the 'static' tag
        for item in canvas.find_all():
            tags = canvas.gettags(item)
            if 'static' not in tags:
                _orig_delete(item)
    else:
        _orig_delete(*args)
canvas.delete = _delete_wrapper

print(f"GUI setup complete.")


# Helper function to map force to color
def _interp_color(t):
    # t: 0.0 (min) .. 1.0 (max)
    # gradient: blue (0) -> green (0.5) -> red (1)
    t = max(0.0, min(1.0, t))
    if t <= 0.5:
        tt = t / 0.5
        c1 = (0, 0, 255)   # blue
        c2 = (0, 255, 0)   # green
    else:
        tt = (t - 0.5) / 0.5
        c1 = (0, 255, 0)   # green
        c2 = (255, 0, 0)   # red
    r = int(c1[0] * (1 - tt) + c2[0] * tt)
    g = int(c1[1] * (1 - tt) + c2[1] * tt)
    b = int(c1[2] * (1 - tt) + c2[2] * tt)
    return (r, g, b)

def _rgb_to_hex(rgb):
    return '#{:02x}{:02x}{:02x}'.format(*rgb)

def force_to_color(force, min_force, max_force):
    # Return a hex color representing the force on the blue->green->red gradient.
    if max_force == min_force:
        norm = 0.0
    else:
        norm = (force - min_force) / (max_force - min_force)
    norm = max(0.0, min(1.0, norm))
    return _rgb_to_hex(_interp_color(norm))

def draw_colorbar(canvas, x, y, width, height, min_force, max_force):
    # Draw a vertical colorbar (top = max_force, bottom = min_force)
    steps = max(2, int(height))
    for i in range(steps):
        t = 1.0 - (i / (steps - 1))
        color = _rgb_to_hex(_interp_color(t))
        y0 = int(y + i * (height / steps))
        y1 = int(y + (i + 1) * (height / steps))
        canvas.create_rectangle(x, y0, x + width, y1, outline=color, fill=color, tags=('static',))
    # labels: max at top, min at bottom, mid
    canvas.create_text(x + width + 5, y + 5, anchor='nw', text=f"{max_force:.2f}", fill='black', tags=('static',))
    canvas.create_text(x + width + 5, y + height / 2, anchor='w', text=f"{(min_force + max_force) / 2:.2f}", fill='black', tags=('static',))
    canvas.create_text(x + width + 5, y + height - 5, anchor='sw', text=f"{min_force:.2f}", fill='black', tags=('static',))

# draw the colorbar on the right side of the canvas (inside the right margin)
draw_colorbar(canvas, cb_x, cb_y, cb_width, cb_height, target_min[2], target_max[2])


# ------------------------------------------------------------------------------------------------------------------------------------------------------
try:
    while True:
        line = ser.readline().decode('utf-8').strip()
        if not line:
            continue
        values = line.split(',')
        if len(values) != input_feature:
            print(f"Invalid input length: {len(values)} (expected {input_feature})")
            continue
        try:
            current_data = np.array([float(v) for v in values], dtype=np.float32)  # length 9
        except ValueError:
            print("Non-numeric data received.")
            continue

        # set initial reference for all 9 channels on first valid read
        if initial_value is None:
            initial_value = current_data.copy()
            print(f"Initial value set: {initial_value}")
            continue

        # compute delta relative to initial for all channels
        delta_all = current_data - initial_value  # length == input_feature

        # For ML inputs use ALL input_feature channels (9)
        sensors_raw = current_data[:input_feature]
        delta_sensors = delta_all[:input_feature]

        # Count how many of the 9 values exceed initial + 70 (strictly greater)
        count_over = int(np.sum(delta_all > 60.0))

        # Always update GUI even if no contact: show "No contact" or use appropriate model
        # Use model2 when 7 or more of the 9 points exceed threshold, else model1
        use_model2 = (count_over >= 7)

        # small-noise cutoff: if none of the input channels have abs(delta) > 80, show No contact
        if not np.any(np.abs(delta_sensors) > 60) and not use_model2:
            canvas.delete("all")
            msg_x = int(plot_x0 + plot_width * 0.5)
            msg_y = int(plot_y0 + plot_height * 0.5)
            canvas.create_text(msg_x, msg_y, text="No contact", fill="gray", tags=('nodata',))
            root.update()
            time.sleep(0.05)
            continue

        # --- normalize sensors using the model-specific mins/maxs (use full 9 entries) ---
        if use_model2:
            mn = col_min2[:input_feature].astype(np.float32)
            mx = col_max2[:input_feature].astype(np.float32)
        else:
            mn = col_min[:input_feature].astype(np.float32)
            mx = col_max[:input_feature].astype(np.float32)
        denom = (mx - mn).astype(np.float32)
        denom[denom == 0] = 1.0
        input_norm = (delta_sensors - mn) / denom
        input_norm = np.clip(input_norm, 0.0, 1.0)

        input_tensor = torch.tensor(input_norm, dtype=torch.float32).unsqueeze(0)  # [1, input_feature]

        if use_model2:
            with torch.no_grad():
                out2 = MN2(input_tensor)
            out_np2 = out2.detach().cpu().numpy().flatten()  # 6 values normalized
            denorm2 = out_np2 * (target_max2 - target_min2) + target_min2
            # extract two predictions
            x1, y1, f1, x2, y2, f2 = [float(v) for v in denorm2]

            # print predictions (normalized raw + denormalized values)
            print(f"[x1={x1:.3f}, y1={y1:.3f}, f1={f1:.3f}, x2={x2:.3f}, y2={y2:.3f}, f2={f2:.3f}]")

            # map both coordinates to canvas
            def map_to_canvas(px, py):
                if target_max[0] != target_min[0]:
                    rx = (px - target_min[0]) / (target_max[0] - target_min[0])
                else:
                    rx = 0.5
                if target_max[1] != target_min[1]:
                    ry = (py - target_min[1]) / (target_max[1] - target_min[1])
                else:
                    ry = 0.5
                rx = max(0.0, min(1.0, rx))
                ry = max(0.0, min(1.0, ry))
                x_c = int(plot_x0 + rx * plot_width)
                y_c = int(plot_y1 - ry * plot_height)
                x_c = max(plot_x0 + 1, min(x_c, plot_x1 - 1))
                y_c = max(plot_y0 + 1, min(y_c, plot_y1 - 1))
                return x_c, y_c

            x_canvas1, y_canvas1 = map_to_canvas(x1, y1)
            x_canvas2, y_canvas2 = map_to_canvas(x2, y2)

            color1 = force_to_color(f1, float(target_min[2]), float(target_max[2]))
            color2 = force_to_color(f2, float(target_min[2]), float(target_max[2]))

            canvas.delete("all")
            r1 = max(6, int(6 + (f1 - target_min[2]) / (target_max[2] - target_min[2]) * 10))
            r2 = max(6, int(6 + (f2 - target_min[2]) / (target_max[2] - target_min[2]) * 10))

            # draw force 1
            canvas.create_oval(x_canvas1 - r1, y_canvas1 - r1, x_canvas1 + r1, y_canvas1 + r1, fill=color1, outline="blue", width=2)
            canvas.create_text(x_canvas1, y_canvas1 - r1 - 10, text=f"F1:{f1:.2f}", fill='black')

            # draw force 2
            canvas.create_oval(x_canvas2 - r2, y_canvas2 - r2, x_canvas2 + r2, y_canvas2 + r2, fill=color2, outline="red", width=2)
            canvas.create_text(x_canvas2, y_canvas2 - r2 - 10, text=f"F2:{f2:.2f}", fill='black')

            # optional: draw dashed line between two forces
            canvas.create_line(x_canvas1, y_canvas1, x_canvas2, y_canvas2, fill='black', dash=(4,4))

        else:
            # single-force model
            with torch.no_grad():
                out1 = MN(input_tensor)
            out_np1 = out1.detach().cpu().numpy().flatten()  # 3 values normalized
            denorm1 = out_np1 * (target_max - target_min) + target_min
            x = float(denorm1[0])
            y = float(denorm1[1])
            force = float(denorm1[2])

            # print prediction (raw normalized + denormalized)
            print(f"[x={x:.3f}, y={y:.3f}, f={force:.3f}]")

            # also print a short summary line for easy parsing / logs
            # print(f"Used Model1 -> X:{x:.2f}, Y:{y:.2f}, Force:{force:.2f}")

            # map to canvas
            if target_max[0] != target_min[0]:
                rx = (x - target_min[0]) / (target_max[0] - target_min[0])
            else:
                rx = 0.5
            if target_max[1] != target_min[1]:
                ry = (y - target_min[1]) / (target_max[1] - target_min[1])
            else:
                ry = 0.5
            rx = max(0.0, min(1.0, rx))
            ry = max(0.0, min(1.0, ry))
            x_canvas = int(plot_x0 + rx * plot_width)
            y_canvas = int(plot_y1 - ry * plot_height)
            x_canvas = max(plot_x0 + 1, min(x_canvas, plot_x1 - 1))
            y_canvas = max(plot_y0 + 1, min(y_canvas, plot_y1 - 1))

            color = force_to_color(force, float(target_min[2]), float(target_max[2]))
            canvas.delete("all")
            r = 8
            canvas.create_oval(x_canvas - r, y_canvas - r, x_canvas + r, y_canvas + r, fill=color, outline="black")
            canvas.create_text(x_canvas, y_canvas - r - 10, text=f"F:{force:.2f}", fill='black')

        root.update()
        time.sleep(0.1)
except KeyboardInterrupt:
    print("Stopped by user.")
finally:
    ser.close()
    root.destroy()
