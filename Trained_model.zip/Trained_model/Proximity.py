import serial
import matplotlib.pyplot as plt
import numpy as np
from collections import deque
import time

class ProximitySignalPlotter:
    def __init__(self, com_port='COM5', baudrate=9600):
        self.com_port = com_port
        self.baudrate = baudrate
        self.serial_conn = None
        self.initial_signal = None
        self.last_signal_value = None
        self.last_update_time = 0
        self.update_interval = 0.5  # Constant update period of 0.2 seconds
        self.fixed_angle = 45  # Always plot at 45 degrees
        
        # Setup the plot with optimized settings
        self.fig, self.ax = plt.subplots(figsize=(10, 8))
        
        # Turn on interactive mode
        plt.ion()
        self.fig.show()
        
        self.setup_plot()
        
        # Initialize plot objects for faster updates
        self.scatter_point = None
        self.text_annotation = None
        
    def setup_plot(self):
        """Setup the 90-degree sector visualization - only once"""
        self.ax.clear()
        self.ax.set_xlim(0, 2)
        self.ax.set_ylim(0, 2)
        self.ax.set_aspect('equal')
        self.ax.set_title('Proximity Signal Strength Visualization (45° Fixed)', 
                         fontsize=16, pad=20)
        
        # Create sector arcs for signal strength reference (static)
        radii = [0.2, 0.4, 0.6, 0.8, 1.0, 1.2, 1.4, 1.6, 1.8]
        angles = np.linspace(0, 90, 30)
        
        for radius in radii:
            theta = np.radians(angles)
            x_arc = radius * np.cos(theta)
            y_arc = radius * np.sin(theta)
            self.ax.plot(x_arc, y_arc, '--', alpha=0.3, color='gray', linewidth=1)
        
        # Add static elements
        self.ax.plot([0, 2], [0, 0], '--', alpha=0.3, color='gray', linewidth=1)
        self.ax.plot([0, 0], [0, 2], '--', alpha=0.3, color='gray', linewidth=1)
        
        # Highlight the 45-degree line
        # x_45 = [0, 2 * np.cos(np.radians(45))]
        # y_45 = [0, 2 * np.sin(np.radians(45))]
        # self.ax.plot(x_45, y_45, '-', alpha=0.7, color='red', linewidth=2, label='45° Line')
        
        # self.ax.plot(0, 0, 'ro', markersize=8, label='Strongest Signal')
        
        # Add labels
        self.ax.text(1.9, 0, '0°', ha='center', va='top', alpha=0.7)
        self.ax.text(0, 1.9, '90°', ha='center', va='center', alpha=0.7)
        # self.ax.text(1.4, 1.4, '45°', ha='center', va='center', alpha=0.7, color='red', fontweight='bold')
        self.ax.legend(loc='upper right')
        
        # Draw once
        self.fig.canvas.draw()
        
    def connect_serial(self):
        """Connect to the serial port"""
        try:
            self.serial_conn = serial.Serial(
                port=self.com_port,
                baudrate=self.baudrate,
                timeout=0.1,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                bytesize=serial.EIGHTBITS
            )
            # Clear any buffered data
            if self.serial_conn.in_waiting:
                self.serial_conn.reset_input_buffer()
                
            print(f"Connected to {self.com_port}")
            return True
        except serial.SerialException as e:
            print(f"Error connecting to {self.com_port}: {e}")
            return False
    
    def read_signal(self):
        """Read and parse the proximity signal"""
        if not self.serial_conn:
            return None, None
            
        try:
            # Check if we have data waiting
            if self.serial_conn.in_waiting > 0:
                # Read line by line
                line = self.serial_conn.readline().decode('utf-8', errors='ignore').strip()
                
                if line and len(line) > 0:
                    try:
                        signal_value = int(line)
                        
                        # Set initial signal if not set
                        if self.initial_signal is None:
                            self.initial_signal = signal_value
                            self.last_signal_value = signal_value
                            print(f"Initial signal set to: {self.initial_signal}")
                            return 0, signal_value
                        
                        return signal_value - self.initial_signal, signal_value
                            
                    except ValueError:
                        print(f"Could not convert to int: '{line}'")
                        return None, None
            else:
                # No data available
                return None, None
                
        except Exception as e:
            print(f"Error reading serial data: {e}")
            return None, None
    
    def calculate_position(self, signal_variation, max_signal=20000):
        """Calculate symbol position - always at 45 degrees"""
        normalized_signal = min(abs(signal_variation) / max_signal, 1.0)
        distance_from_center = 1.8 * (1 - normalized_signal)
        
        # Always use 45 degrees
        angle_radians = np.radians(self.fixed_angle)
        
        x = distance_from_center * np.cos(angle_radians)
        y = distance_from_center * np.sin(angle_radians)
        
        return x, y, normalized_signal, self.fixed_angle
    
    def update_plot(self, x, y, signal_strength, angle):
        """Update the plot efficiently"""
        # Remove previous elements if they exist
        if self.scatter_point:
            self.scatter_point.remove()
        if self.text_annotation:
            self.text_annotation.remove()
        
        # Calculate visual properties
        size = 50 + signal_strength * 200
        alpha = 0.3 + signal_strength * 0.7
        color = (signal_strength, 0, 1 - signal_strength)
        
        # Add new point
        self.scatter_point = self.ax.scatter(x, y, s=size, c=[color], alpha=alpha, 
                                           marker='o', edgecolors='black', linewidths=1)
        
        # Add text annotation
        info_text = f'Strength: {signal_strength:.2f}\nDist: {np.sqrt(x**2 + y**2):.2f}'
        self.text_annotation = self.ax.text(x + 0.1, y + 0.1, info_text, 
                                          ha='left', va='bottom', fontsize=8,
                                          bbox=dict(boxstyle="round,pad=0.3", 
                                                  facecolor="white", alpha=0.8))
        
        # Update title with current values
        self.ax.set_title(f'Proximity Signal - Strength: {signal_strength:.2f} (45° Fixed, 0.2s Update)', 
                         fontsize=14, pad=20)
        
        # Efficient update
        self.fig.canvas.draw_idle()
        self.fig.canvas.flush_events()
    
    def run_continuous(self):
        """Main loop with constant 0.2s update period"""
        if not self.connect_serial():
            return
        
        print("Starting proximity signal visualization...")
        print("Settings: 45° fixed angle, 0.2s constant update period")
        print("Press Ctrl+C to stop")
        
        update_count = 0
        
        try:
            while True:
                current_time = time.time()
                
                # Check if it's time to update (every 0.2 seconds)
                if current_time - self.last_update_time >= self.update_interval:
                    signal_variation, raw_signal = self.read_signal()
                    
                    if signal_variation is not None:
                        x, y, signal_strength, angle = self.calculate_position(signal_variation)
                        self.update_plot(x, y, signal_strength, angle)
                        update_count += 1
                        print(f"Update {update_count}: Raw={raw_signal}, Variation={signal_variation}, Strength={signal_strength:.2f}")
                    else:
                        # Even if no new signal, still update with last known value for constant timing
                        if self.last_signal_value is not None:
                            signal_variation = self.last_signal_value - self.initial_signal
                            x, y, signal_strength, angle = self.calculate_position(signal_variation)
                            self.update_plot(x, y, signal_strength, angle)
                            update_count += 1
                            print(f"Update {update_count}: (No new data) Using last signal, Strength={signal_strength:.2f}")
                    
                    self.last_update_time = current_time
                
                # Small sleep to prevent CPU overload
                time.sleep(0.01)
                
        except KeyboardInterrupt:
            print(f"\nStopping visualization... Total updates: {update_count}")
        finally:
            if self.serial_conn:
                self.serial_conn.close()
            plt.ioff()

# Test function with constant 0.2s updates at 45 degrees
def test_continuous_simulation():
    """Test with continuous simulated data at fixed 45 degrees"""
    plotter = ProximitySignalPlotter()
    
    print("Starting simulation: 45° fixed angle, 0.2s update period")
    print("Press Ctrl+C to stop")
    
    try:
        counter = 0
        last_update_time = 0
        
        while True:
            current_time = time.time()
            
            # Constant 0.2s update period
            if current_time - last_update_time >= 0.2:
                # Simulate proximity signals
                base_signal = 8000 + 6000 * np.sin(counter * 0.1)  # Oscillating signal
                noise = np.random.normal(0, 50)
                simulated_signal = int(max(0, base_signal + noise))
                signal_variation = simulated_signal
                
                x, y, signal_strength, angle = plotter.calculate_position(signal_variation)
                plotter.update_plot(x, y, signal_strength, angle)
                
                print(f"Update {counter}: Signal={simulated_signal}, Strength={signal_strength:.2f}, Distance={np.sqrt(x**2 + y**2):.2f}")
                
                counter += 1
                last_update_time = current_time
            
            time.sleep(0.01)  # Small sleep to prevent CPU overload
            
    except KeyboardInterrupt:
        print(f"\nStopping simulation... Total updates: {counter}")
    finally:
        plt.ioff()

if __name__ == "__main__":
    # CHOOSE ONLY ONE OF THE FOLLOWING OPTIONS:
    
    # Option 1: For real hardware (continuous)
    plotter = ProximitySignalPlotter('COM5', 9600)
    plotter.run_continuous()
    
    # Option 2: For continuous simulation (recommended for testing)
    # test_continuous_simulation()