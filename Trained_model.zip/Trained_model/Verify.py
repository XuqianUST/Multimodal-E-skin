import torch
import numpy as np
import serial
import time
import tkinter as tk
from tkinter import Canvas

# define input feature size
input_feature = 8  # Now expecting 8 inputs

# load model path
model_path = r'd:/OneDrive/HKUST/(Doing)_Bio_inspired_Origami_Fish_Scale/ML_Code/Trained_model/5e-5_4_8-16-32_0_0.pth'

# define the model architecture
class MNN(torch.nn.Module):
    def __init__(self, input_feature=8, l1_size=8, l2_size=16, l3_size=32, dropout_p=0, output_feature=3):
        super(MNN, self).__init__()
        self.all = torch.nn.Sequential(
            torch.nn.Linear(input_feature, l1_size),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_p),
            torch.nn.Linear(l1_size, l2_size),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_p),
            torch.nn.Linear(l2_size, l3_size),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_p),
            torch.nn.Linear(l3_size, l2_size),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_p),
            torch.nn.Linear(l2_size, l1_size),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_p),
            torch.nn.Linear(l1_size, output_feature),
            torch.nn.Sigmoid()
        )
    def forward(self, x):
        output2 = self.all(x)
        return output2

# instantiate the model
MN = MNN()

# load the trained model weights
statedict = torch.load(model_path, map_location='cuda:0')
MN.load_state_dict(statedict)
MN.eval()

import pandas as pd
import os
import sys

# --- Configure CSV evaluation (no COM5, no GUI, no plotting) ---
CSV_PATH = r'd:/OneDrive/HKUST/(Doing)_Bio_inspired_Origami_Fish_Scale/ML_Code/Dataset/Verify3.csv'  # update if needed
OUT_CSV = os.path.join(os.path.dirname(CSV_PATH), 'test_errors.csv')

# sensor/target normalization used during training (keep consistent)
col_min = np.array([-551, -611, -524, -703, -626, -658, -569, -729], dtype=np.float32)
col_max = np.array([504, 526, 458, 603, 517, 525, 435, 588], dtype=np.float32)
target_min = np.array([0, 0, 0.2], dtype=np.float32)
target_max = np.array([102, 66, 1], dtype=np.float32)

def evaluate_csv(csv_path, out_csv):
    # Expect CSV columns: X,Y,Force,s0,s1,...,s7 (header allowed)
    df = pd.read_csv(csv_path, header=0)
    if df.shape[1] < 11:
        raise ValueError(f"CSV must contain at least 11 columns (X,Y,Force,8 sensors). Found {df.shape[1]}")
    targets = df.iloc[:, 0:3].to_numpy(dtype=np.float32)   # true X,Y,Force
    sensors = df.iloc[:, 3:11].to_numpy(dtype=np.float32)  # 8 sensor columns

    # normalize sensors using training mins/maxs
    denom = (col_max - col_min).astype(np.float32)
    denom[denom == 0] = 1.0
    sensors_norm = (sensors - col_min) / denom
    sensors_norm = np.clip(sensors_norm, 0.0, 1.0)

    # model inference (batch)
    MN.eval()
    with torch.no_grad():
        inputs = torch.tensor(sensors_norm, dtype=torch.float32)
        preds = MN(inputs).cpu().numpy()  # normalized preds

    # denormalize preds
    denorm_preds = preds * (target_max - target_min) + target_min

    # compute errors
    errors = denorm_preds - targets
    abs_errors = np.abs(errors)

    out_df = pd.DataFrame({
        'true_X': targets[:, 0],
        'true_Y': targets[:, 1],
        'true_F': targets[:, 2],
        'pred_X': denorm_preds[:, 0],
        'pred_Y': denorm_preds[:, 1],
        'pred_F': denorm_preds[:, 2],
        'err_X': errors[:, 0],
        'err_Y': errors[:, 1],
        'err_F': errors[:, 2],
        'abs_err_X': abs_errors[:, 0],
        'abs_err_Y': abs_errors[:, 1],
        'abs_err_F': abs_errors[:, 2],
    })

    out_df.to_csv(out_csv, index=False)
    mae = out_df[['abs_err_X', 'abs_err_Y', 'abs_err_F']].mean()
    print(f"Saved errors to {out_csv}")
    print(f"Mean absolute errors: X={mae['abs_err_X']:.3f}, Y={mae['abs_err_Y']:.3f}, F={mae['abs_err_F']:.3f}")
    return out_df

if __name__ == '__main__':
    if not os.path.exists(CSV_PATH):
        print(f"CSV not found: {CSV_PATH}")
        sys.exit(1)
    evaluate_csv(CSV_PATH, OUT_CSV)
