import torch
import numpy as np
import serial
import time
import tkinter as tk
from tkinter import Canvas

# define input feature size
input_feature = 8  # Now expecting 8 inputs

# load model path
model_path = r'd:/OneDrive/HKUST/(Doing)_Bio_inspired_Origami_Fish_Scale/ML_Code/Trained_model/5e-5_4_8-16-32_0_0.pth'

# define the model architecture
class MNN(torch.nn.Module):
    def __init__(self, input_feature=8, l1_size=8, l2_size=16, l3_size=32, dropout_p=0, output_feature=3):
        super(MNN, self).__init__()
        self.all = torch.nn.Sequential(
            torch.nn.Linear(input_feature, l1_size),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_p),
            torch.nn.Linear(l1_size, l2_size),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_p),
            torch.nn.Linear(l2_size, l3_size),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_p),
            torch.nn.Linear(l3_size, l2_size),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_p),
            torch.nn.Linear(l2_size, l1_size),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_p),
            torch.nn.Linear(l1_size, output_feature),
            torch.nn.Sigmoid()
        )
    def forward(self, x):
        output2 = self.all(x)
        return output2

# instantiate the model
MN = MNN()

# load the trained model weights
statedict = torch.load(model_path, map_location='cuda:0')
MN.load_state_dict(statedict)
MN.eval()

# Serial port settings
SERIAL_PORT = 'COM5'
BAUD_RATE = 9600
TIMEOUT = 1

ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=TIMEOUT)
print(f"Listening to {SERIAL_PORT}...")

initial_value = None
# Replace these with your actual training min/max arrays
col_min = np.array([-551, -611, -524, -703, -626, -658, -569, -729])  # shape: (8,)
col_max = np.array([504, 526, 458, 603, 517, 525, 435, 588])  # shape: (8,)

target_min = np.array([0, 0, 0.2])
target_max = np.array([102, 66, 1])

# GUI setup
root = tk.Tk()
root.title("Tactile Sensor Visualization")
canvas_width = 800
canvas_height = 800
canvas = Canvas(root, width=canvas_width, height=canvas_height, bg='white')
canvas.pack()

# Plot margins (leave room for axis labels and colorbar)
left_margin = 50
right_margin = 80
top_margin = 20
bottom_margin = 50

plot_x0 = left_margin
plot_y0 = top_margin
plot_x1 = canvas_width - right_margin
plot_y1 = canvas_height - bottom_margin
plot_width = plot_x1 - plot_x0
plot_height = plot_y1 - plot_y0

# Draw plot border and axis lines (tag as static so they are not removed)
canvas.create_rectangle(plot_x0, plot_y0, plot_x1, plot_y1, outline='black', tags=('static',))

# draw axis lines just outside the plot rectangle so ticks/labels sit outside
axis_offset = 1
canvas.create_line(plot_x0, plot_y1 + axis_offset, plot_x1, plot_y1 + axis_offset, width=2, tags=('static',))  # x axis just below plot
canvas.create_line(plot_x0 - axis_offset, plot_y0, plot_x0 - axis_offset, plot_y1, width=2, tags=('static',))  # y axis just left of plot

# Axis labels and ticks based on known target ranges
x_min, y_min = float(target_min[0]), float(target_min[1])
x_max, y_max = float(target_max[0]), float(target_max[1])

# X ticks (draw ticks outside the plot, below the axis)
num_xticks = 5
for i in range(num_xticks + 1):
    t = i / num_xticks
    x = int(plot_x0 + t * plot_width)
    y_tick = plot_y1 + axis_offset
    canvas.create_line(x, y_tick, x, y_tick + 6, tags=('static',))
    val = x_min + t * (x_max - x_min)
    canvas.create_text(x, y_tick + 18, text=f"{val:.0f}", tags=('static',))

# Y ticks (draw ticks outside the plot, to the left of the axis)
num_yticks = 5
for i in range(num_yticks + 1):
    t = i / num_yticks
    y = int(plot_y1 - t * plot_height)
    x_tick = plot_x0 - axis_offset
    canvas.create_line(x_tick - 6, y, x_tick, y, tags=('static',))
    val = y_min + t * (y_max - y_min)
    canvas.create_text(x_tick - 22, y, text=f"{val:.0f}", tags=('static',))

# Axis titles (move them outward slightly)
canvas.create_text(plot_x0 + plot_width / 2, canvas_height - 6, text="X position", font=("Arial", 10, "bold"), tags=('static',))
canvas.create_text(10, plot_y0 + plot_height / 2, text="Y position", angle=90, font=("Arial", 10, "bold"), tags=('static',))

# Reserve space for colorbar on the right and add label (colorbar itself will be drawn later)
# compute colorbar geometry so it fits inside the right margin and inside the plot vertical bounds
cb_width = 20
cb_height = max(40, plot_height - 20)            # keep a small vertical padding so it doesn't overflow
cb_x = plot_x1 + max(0, (right_margin - cb_width) // 2)  # center the colorbar inside the right margin
cb_y = plot_y0 + 10                              # small top padding

# place the "Force" label and leave numeric labels to draw_colorbar
canvas.create_text(cb_x + cb_width - 8, cb_y - 8, text="Force", font=("Arial", 10, "bold"), tags=('static',))
# add min/max labels placeholders (will be overwritten/duplicated by draw_colorbar call)
# canvas.create_text(cb_x + cb_width + 8, cb_y + cb_height + 6, text=f"{target_min[2]:.2f}", tags=('static',))
# canvas.create_text(cb_x + cb_width + 8, cb_y - 18, text=f"{target_max[2]:.2f}", tags=('static',))

# Prevent the main loop from completely erasing the static elements:
# replace canvas.delete so that "all" removes only non-static items
_orig_delete = canvas.delete
def _delete_wrapper(*args):
    if len(args) == 1 and args[0] == "all":
        # delete everything that does NOT have the 'static' tag
        for item in canvas.find_all():
            tags = canvas.gettags(item)
            if 'static' not in tags:
                _orig_delete(item)
    else:
        _orig_delete(*args)
canvas.delete = _delete_wrapper

print(f"GUI setup complete.")


# Helper function to map force to color
def _interp_color(t):
    # t: 0.0 (min) .. 1.0 (max)
    # gradient: blue (0) -> green (0.5) -> red (1)
    t = max(0.0, min(1.0, t))
    if t <= 0.5:
        tt = t / 0.5
        c1 = (0, 0, 255)   # blue
        c2 = (0, 255, 0)   # green
    else:
        tt = (t - 0.5) / 0.5
        c1 = (0, 255, 0)   # green
        c2 = (255, 0, 0)   # red
    r = int(c1[0] * (1 - tt) + c2[0] * tt)
    g = int(c1[1] * (1 - tt) + c2[1] * tt)
    b = int(c1[2] * (1 - tt) + c2[2] * tt)
    return (r, g, b)

def _rgb_to_hex(rgb):
    return '#{:02x}{:02x}{:02x}'.format(*rgb)

def force_to_color(force, min_force, max_force):
    # Return a hex color representing the force on the blue->green->red gradient.
    if max_force == min_force:
        norm = 0.0
    else:
        norm = (force - min_force) / (max_force - min_force)
    norm = max(0.0, min(1.0, norm))
    return _rgb_to_hex(_interp_color(norm))

def draw_colorbar(canvas, x, y, width, height, min_force, max_force):
    # Draw a vertical colorbar (top = max_force, bottom = min_force)
    steps = max(2, int(height))
    for i in range(steps):
        t = 1.0 - (i / (steps - 1))
        color = _rgb_to_hex(_interp_color(t))
        y0 = int(y + i * (height / steps))
        y1 = int(y + (i + 1) * (height / steps))
        canvas.create_rectangle(x, y0, x + width, y1, outline=color, fill=color, tags=('static',))
    # labels: max at top, min at bottom, mid
    canvas.create_text(x + width + 5, y + 5, anchor='nw', text=f"{max_force:.2f}", fill='black', tags=('static',))
    canvas.create_text(x + width + 5, y + height / 2, anchor='w', text=f"{(min_force + max_force) / 2:.2f}", fill='black', tags=('static',))
    canvas.create_text(x + width + 5, y + height - 5, anchor='sw', text=f"{min_force:.2f}", fill='black', tags=('static',))

# draw the colorbar on the right side of the canvas (inside the right margin)
draw_colorbar(canvas, cb_x, cb_y, cb_width, cb_height, target_min[2], target_max[2])


# ------------------------------------------------------------------------------------------------------------------------------------------------------
try:
    while True:
        line = ser.readline().decode('utf-8').strip()
        if not line:
            continue
        values = line.split(',')
        if len(values) != input_feature:
            print(f"Invalid input length: {len(values)}")
            continue
        try:
            current_data = np.array([float(v) for v in values], dtype=np.float32)
        except ValueError:
            print("Non-numeric data received.")
            continue
        if initial_value is None:
            initial_value = current_data.copy()
            print(f"Initial value set: {initial_value}")
            continue
        input_data = (current_data - initial_value)
        # print(f"input_data (after initial adjustment): {input_data}")

        # Only perform prediction if at least one adjusted sensor value's absolute value > 50
        if not np.any(np.abs(input_data) > 80):
            # no significant contact — clear previous dynamic markers and show a small "no contact" hint
            canvas.delete("all")               # _delete_wrapper will keep 'static' items (axes, colorbar)
            # optional light message in the plot area (non-static so will be cleared on next update)
            msg_x = int(plot_x0 + plot_width * 0.5)
            msg_y = int(plot_y0 + plot_height * 0.5)
            canvas.create_text(msg_x, msg_y, text="No contact", fill="gray", tags=('nodata',))
            root.update()
            time.sleep(0.05)
            continue

        input_data = (input_data - col_min) / (col_max - col_min)
        input_tensor = torch.tensor(input_data, dtype=torch.float32).unsqueeze(0)  # shape: [1, input_feature]
        with torch.no_grad():
            output = MN(input_tensor)
        # ensure CPU numpy conversion
        output_np = output.detach().cpu().numpy().flatten()
        denorm_output = output_np * (target_max - target_min) + target_min

        # print predicted raw and denormalized outputs for debugging
        print(f"raw_pred: {output_np}, denorm_pred: {denorm_output}")

        # use denorm_output[0]=X, [1]=Y, [2]=force
        x = float(denorm_output[0])
        y = float(denorm_output[1])
        force = float(denorm_output[2])

        # Map denormalized X,Y into the plot rectangle (not full canvas)
        # left->right: plot_x0 .. plot_x1
        # top->bottom: plot_y0 .. plot_y1  (we invert so physical Y up maps upward)
        if target_max[0] != target_min[0]:
            rx = (x - target_min[0]) / (target_max[0] - target_min[0])
        else:
            rx = 0.5
        if target_max[1] != target_min[1]:
            ry = (y - target_min[1]) / (target_max[1] - target_min[1])
        else:
            ry = 0.5

        # clamp ratios
        rx = max(0.0, min(1.0, rx))
        ry = max(0.0, min(1.0, ry))

        x_canvas = int(plot_x0 + rx * plot_width)
        # invert Y so larger physical Y is plotted higher on the plot
        y_canvas = int(plot_y1 - ry * plot_height)

        # keep the marker inside the plot rectangle (leave 1px margin)
        x_canvas = max(plot_x0 + 1, min(x_canvas, plot_x1 - 1))
        y_canvas = max(plot_y0 + 1, min(y_canvas, plot_y1 - 1))

        color = force_to_color(force, float(target_min[2]), float(target_max[2]))

        # erase non-static items (your delete wrapper keeps static items)
        canvas.delete("all")
        # draw point relative to plot area
        r = 8
        canvas.create_oval(x_canvas - r, y_canvas - r, x_canvas + r, y_canvas + r, fill=color, outline="black")
        canvas.create_text(x_canvas, y_canvas - r - 10, text=f"F:{force:.2f}", fill='black')
        # canvas.create_text(plot_x0 + 6, plot_y0 + 12, text=f"X:{x:.1f}", anchor='w', tags=('static',))
        # canvas.create_text(plot_x0 + 6, plot_y0 + 28, text=f"Y:{y:.1f}", anchor='w', tags=('static',))
        root.update()
        time.sleep(0.1)
except KeyboardInterrupt:
    print("Stopped by user.")
finally:
    ser.close()
    root.destroy()
